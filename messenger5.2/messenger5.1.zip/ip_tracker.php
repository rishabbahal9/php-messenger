<?php
	SESSION_START();
	$_SESSION['blue_element']="120.89.76.169";
	$_SESSION['blue_element']=$_SERVER['REMOTE_ADDR'];
?>